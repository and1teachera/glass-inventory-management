package com.zlatenov.glasswarehouse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GlassInventoryManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
